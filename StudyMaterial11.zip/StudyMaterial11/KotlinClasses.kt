/***
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
***/

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// In Java
//		Clasess Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Clasess Are Final By Default
//			Can't Be Inherited From
//		Member Functions Are Also Final By Default
//			Can't Be Overridden
//		override Keyword Required To Override Parent Class Function

// error: this type is final, so it cannot be inherited from
// class View {

open class View {
	// error: 'click' in 'View' is final and cannot be overridden
	// fun click() = println("View Clicked!")
	open fun click() = println("View Clicked!")
}

// Inheritance Of View Class TO Button Class
//		Creates Relationship Between Types/Classes
//		Creating Relationship Between View and Button
//			View Class/Type Parent Class/Super Class/Super Type
//			Button Class/Type Child Class/Sub Class/Sub Type

// error: this type has a constructor, and thus must be initialized here
// class Button : View {
class Button : View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier
	// fun click() = println("Button Clicked!")

	// Function Override
	// Redefining click Function In Child Class/Subclass
	override fun click() {
		// super.click()
		println("Button Clicked!")	
	}

	// Function Overloading
	//		Function Are Overloaded Based On
	//			Number Of Arguments
	//			Types Of Arguments
	fun click(something: Int) = println("Button Clicked! $something")
	fun click(something: Int, somethingMore: Int) = println("Button Clicked! $something $somethingMore")
	fun click(something: Double) = println("Button Clicked! $something")

	fun magic() = println("Button Magic...")
}

fun playWithInheritance() {
	val view = View() 		// Creating Instance/Object Of View Type/Class
	view.click()

	val button = Button() 	// Creating Instance/Object Of Button Type/Class
	button.click() 			// Called click With No Arguments
	button.click(10)		// Called click With One Int Argument
	button.click(11, 22)    // Called click With Two Int Arguments
	button.click( 99.99 )   // Called click With One Double Argument

	button.magic()

	val viewAgain: View = View()
	viewAgain.click()
	// viewAgain.magic()

	// Reference Of Parent Type Can STore objecct Store Object of Child Class
	val viewOnceAgain: View = Button()
	viewOnceAgain.click()
	// viewOnceAgain.magic()

	val letBringBackKiddu = viewOnceAgain as Button
	letBringBackKiddu.click()
	letBringBackKiddu.magic()


}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

open class View1 {
	open fun click() = println("View Clicked!")
}

// Inheritance Of View Class TO Button Class
class Button1 : View1() {
	override fun click() = println("Button Clicked!")
	fun magic() = println("Button Magic...")
}

// showOff() Extension Function On Type View1
fun View1.showOff() 	= println("View1 showOff Called...")
// showOff() Extension Function On Type Button1
fun Button1.showOff() 	= println("Button1 showOff Called...")

fun playWithInheritanceAgain() {
	val view = View1()
	view.click()
	view.showOff()

	val button = Button1()
	button.click()
	button.magic()
	button.showOff()

	val viewAgain: View1 = View1()
	viewAgain.click()
	viewAgain.showOff()
	// viewAgain.magic()

	// Reference Of Parent Type Can STore objecct Store Object of Child Class
	val viewOnceAgain: View1 = Button1()
	viewOnceAgain.click()
	// viewOnceAgain.magic()

	// Extension Function Doesn't Participate In Overriding
	viewOnceAgain.showOff()
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// What To Do?
// In Kotlin
// interface Are open By Default
// interface Members Are Also open By Default
interface Clickable {
	fun click()
	fun clickMore(something: Int)
}

// Concrete Classes
//		How To Do, When To Do, Which Way To Do, When???
// In Java
//		class Button2 implements Clickable
class Button2 : Clickable {
	override fun click() = println("Button2 Clicked!")
	override fun clickMore(something: Int) = println("Button2 Clicked More!!! $something")
}

fun playWithClickable() {
	// You Can't Create Instances Of Interface
	// val clickable = Clickable()
	val button = Button2()
	button.click()
	button.clickMore( something = 99 )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

interface ClickableAgain {
	fun click()
	fun clickMore(something: Int)
}

interface FocusableAgain {
	fun focus()
}

// Concrete Classes
//		How To Do, When To Do, Which Way To Do, When???
// In Java
//		class Button3 implements ClickableAgain, FocusableAgain { 	}
class Button3 : ClickableAgain, FocusableAgain {
	override fun click() = println("Button3 Clicked!")
	override fun clickMore(something: Int) = println("Button3 Clicked More!!! $something")
	override fun focus() = println("Button3 Focusing...")
}

fun playWithClickableAgain() {
	// You Can't Create Instances Of Interface
	// val clickable = Clickable()
	val button = Button3()
	button.click()
	button.clickMore( something = 99 )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

interface ClickableMore {
	fun click()
	fun showOff( focus: Boolean ) = println("ClickableMore showOff!!!")
}

// Inferface With Default Implementation
interface FocusableMore {
	fun focus() = println("FocusableMore Focusing...") // Default Implementation
	fun showOff( focus: Boolean ) = println("FocusableMore showOff!!!")
}

// Concrete Classes
//		How To Do, When To Do, Which Way To Do, When???
class Button4 : ClickableMore, FocusableMore {
	override fun click() = println("Button4 Clicked!")
	// override fun showOff() = println("Button4 showOff!")
	override fun showOff( focus: Boolean ) {
		// error: many supertypes available, please specify the one 
		// you mean in angle brackets, e.g. 'super<Foo>'
		// super.showOff()

		// Custom Logic i.e. Your Own Logic
		if( focus ) super<FocusableMore>.showOff( focus )
		else super<ClickableMore>.showOff( focus )
	}
}

fun playWithClickableFocusableMore() {
	// You Can't Create Instances Of Interface
	// val clickable = Clickable()
	val button = Button4()
	button.click()
	button.focus()
	button.showOff( false )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithInheritanceAgain")
	playWithInheritanceAgain()

	println("\nFunction : playWithClickable")
	playWithClickable()

	println("\nFunction : playWithClickableAgain")
	playWithClickableAgain()

	println("\nFunction : playWithClickableFocusableMore")
	playWithClickableFocusableMore()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//__________________________________________________________
/*
https://codebunk.com/b/1061100615545/
https://codebunk.com/b/1061100615545/
https://codebunk.com/b/1061100615545/
*/
//__________________________________________________________

