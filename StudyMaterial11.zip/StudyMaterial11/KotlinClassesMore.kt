/***
kotlinc KotlinClassesMore.kt -include-runtime -d classesMore.jar
java -jar classesMore.jar 
***/

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

data class Subject(val name: String, val grade: Char, val points: Double, val credits: Double )

			//Person Class Constructor Defintion
// open class Person( open val firstName: String, open val lastName: String ) {
open class Person( val firstName: String, val lastName: String ) {
	val fullName 	= "$firstName $lastName"

	fun fullName()	= "$firstName $lastName"
}

// Student Class Inheriting From Person Class 		 // Person Constructor Call 
// class Student( override val firstName: String, override val lastName: String ) : Person( firstName, lastName )
	// Student Class Constructor Definition
	//		Please NOTE THAT we are not redefining the properties viz. firstName And lastName.
	//		Because These Are Defined In Person Class ie.. Parent Class
	// 		Gettin Initialised Using Parent Class Constructor Call
open class Student( firstName: String, lastName: String ) : Person( firstName, lastName ) {
	val passedSubjects : MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		println( "Grades Of : $fullName" )

		for ( subject in passedSubjects ) println("\t$subject")
		for ( subject in failedSubjects ) println("\t$subject")
	}

	fun isPassed() : Boolean {
		return failedSubjects.size <= 2
	}
}

fun playWithClassesInheritance() {
	//						Named Arguments
	val gabbar1  = Person( firstName = "Gabbar", lastName = "Singh")
	val basanti1 = Person( firstName = "Basanti", lastName = "Only")

	println( gabbar1.fullName )
	println( basanti1.fullName )

	println( gabbar1.fullName() )
	println( basanti1.fullName() )

	val gabbar  = Student( firstName = "Gabbar", lastName = "Singh")
	val basanti = Student( firstName = "Basanti", lastName = "Only")
	val alice 	= Student( firstName = "Alice", lastName = "Carol")		
	println( gabbar.fullName )
	println( basanti.fullName )
	println( alice.fullName )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithStudentGrades() {
	val gabbar  = Student( firstName = "Gabbar", lastName = "Singh")
	val basanti = Student( firstName = "Basanti", lastName = "Only")

//  class Subject(val name: String, val grade: Char, val points: Double, val credits: Double )
	val decoit 		= Subject(name = "Decoiti", grade = 'A', points = 10.0, credits = 4.0)
	val shooting 	= Subject(name = "Shooting", grade = 'B', points = 8.0, credits = 3.0)
	val horseRiding = Subject(name = "Horse Riding", grade = 'C', points = 6.0, credits = 3.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( shooting )
	gabbar.recordGrade( horseRiding )

	val dancing 	= Subject(name = "Dancing", grade = 'B', points = 9.0, credits = 3.0)
	val chitchat 	= Subject(name = "Chit Chatting", grade = 'A', points = 10.0, credits = 3.0)
	val horseCart 	= Subject(name = "Horse Carting", grade = 'A', points = 10.0, credits = 3.0)

	basanti.recordGrade( dancing )
	basanti.recordGrade( chitchat )
	basanti.recordGrade( horseCart )

	gabbar.printGrades()
	basanti.printGrades()
	println(" Gabbar  Passed: ${ gabbar.isPassed() } " )
	println(" Basanti Passed: ${ basanti.isPassed() } " )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

data class Game(val name: String, val grade: Char, val points: Double)

// StudentAthele Inheriting From Student Class
//															Calling Parent Class Constructor				
	//StudentAthete Class Constructor Defintion	   
class StudentAthlete( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGame( game: Game ) = gamesPlayed.add( game )

	override fun printGrades() {
		super.printGrades()

		for( game in gamesPlayed ) println("\t$game")
	}
}

fun playWithStudentAthlete() {
	val gabbar  = StudentAthlete( firstName = "Gabbar", lastName = "Singh")
	val basanti = StudentAthlete( firstName = "Basanti", lastName = "Only")

//  class Subject(val name: String, val grade: Char, val points: Double, val credits: Double )
	val decoit 		= Subject(name = "Decoiti", grade = 'A', points = 10.0, credits = 4.0)
	val horseRiding = Game(name = "Horse Riding", grade = 'C', points = 6.0)
	val shooting 	= Game(name = "Shooting", grade = 'B', points = 8.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGame( shooting )
	gabbar.recordGame( horseRiding )

	val dancing 	= Subject(name = "Dancing", grade = 'B', points = 9.0, credits = 3.0)
	val chitchat 	= Subject(name = "Chit Chatting", grade = 'A', points = 10.0, credits = 3.0)
	val horseCart 	= Game(name = "Horse Carting", grade = 'A', points = 10.0)

	basanti.recordGrade( dancing )
	basanti.recordGrade( chitchat )
	basanti.recordGame( horseCart )

	gabbar.printGrades()
	basanti.printGrades()
	println(" Gabbar  Passed: ${ gabbar.isPassed() } " )
	println(" Basanti Passed: ${ basanti.isPassed() } " )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

open class BandMember( firstName: String, lastName: String ) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer( firstName: String, lastName: String ) : BandMember(firstName, lastName) {
	override val minimumPracticeTime : Int
		get() { return 3 }
}

class FlutePlayer( firstName: String, lastName: String )  : BandMember(firstName, lastName) {
	override val minimumPracticeTime : Int
		get() { return 4 }
}


fun playWithRuntimeTypeCheck() {
	val g : GuitarPlayer = GuitarPlayer("Taylor",  "Swift")

	println( g.fullName )

	if ( g is GuitarPlayer ) println("guitarPlayer Of Type GuitarPlayer")
	if ( g is BandMember ) 	 println("guitarPlayer Of Type BandMember")
	if ( g is Student ) 	 println("guitarPlayer Of Type Student")
	if ( g is Person ) 		 println("guitarPlayer Of Type Person")

	val reference1 = g
  	val reference2 : BandMember = g
	val reference3 : Student 	= g
	val reference4 : Person 	= g

	if ( reference1 is GuitarPlayer ) println("reference1 Of Type GuitarPlayer")
	if ( reference1 is BandMember )   println("reference1 Of Type BandMember")
	if ( reference1 is Student ) 	  println("reference1 Of Type Student")
	if ( reference1 is Person ) 	  println("reference1 Of Type Person")

	if ( reference2 is GuitarPlayer ) println("reference2 Of Type GuitarPlayer")
	if ( reference2 is BandMember )   println("reference2 Of Type BandMember")
	if ( reference2 is Student ) 	  println("reference2 Of Type Student")
	if ( reference2 is Person ) 	  println("reference2 Of Type Person")

	val shakira = BandMember("Shakira", "Isabel")
	if ( shakira is GuitarPlayer ) println("shakira Of Type GuitarPlayer")
	if ( shakira is BandMember )   println("shakira Of Type BandMember")
	if ( shakira is Student ) 	   println("shakira Of Type Student")
	if ( shakira is Person ) 	   println("shakira Of Type Person")

	val milkha = StudentAthlete("Milkha", "Singh")
	if ( milkha is Student ) 	  	println("milkha Of Type Student")
	if ( milkha is Person ) 	  	println("milkha Of Type Person")
	if ( milkha is StudentAthlete ) println("milkha Of Type StudentAthlete")

	// // error: incompatible types: GuitarPlayer and StudentAthlete
	// if ( milkha is GuitarPlayer ) println("milkha Of Type GuitarPlayer")
	// // error: incompatible types: BandMember and StudentAthlete	
	// if ( milkha is BandMember )   println("milkha Of Type BandMember")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class Client1( val name: String, val postalCode: Int ) {
	override fun toString() : String {
		return "Client1(name = $name, postalCode = $postalCode)"
	}

}

fun playWithClient1() {
	val veeru = Client1("Veeru", 999888 )
	println( "Name: ${veeru.name} ")
	println( "Code: ${veeru.postalCode} ")

	println( veeru ) // println( veeru.toString() )

	val veeruDuplicate = Client1("Veeru", 999888 ) 
	println("Checking Same To Same Or Not...")
	println( veeru == veeruDuplicate ) // println( veeru.equals( veeruDuplicate ) )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class Client2( val name: String, val postalCode: Int ) {
	// name : String 
	// 	get() = title + name
	override fun toString() : String {
		return "Client2(name=$name, postalCode=$postalCode)"
	}

	override fun equals( other: Any? ) : Boolean {
		println("Equals Function Getting Called...")
		if ( other == null || other !is Client2 ) return false
		return name == other.name && postalCode == other.postalCode
	}	
}

fun playWithClient2() {
	val veeru = Client2("Veeru", 999888 )
	println( "Name: ${veeru.name} ")
	println( "Code: ${veeru.postalCode} ")
//  Compiler Will Convert Following Line Of Code To println( veeru.toString() )
	println( veeru ) 	// println( veeru.toString() )

	val veeruDuplicate = Client2("Veeru", 999888 )
	println("Checking Same To Same Or Not...")
	//  Compiler Will Convert Following Line Of Code To println( veeru.equals( veeruDuplicate ) )
	println( veeru == veeruDuplicate ) // println( veeru.equals( veeruDuplicate ) )

	val reference1 = veeru
	println( veeru == reference1 ) 		// println( veeru.equals( reference1 ) )
}

//_____________________________________________________________________
//
//	Java Object Class Documentation Link
// 	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
//		Study toString()	Function
//		Study equal() 		Function 
//		Study hashCode() 	Function
//_____________________________________________________________________
//
// Data Classes
//		Compiler Will Generate Following Functions Code
//		1. toString() 	Method With Code
//				Includes All The Properties
//		2. equals() 	Method With Code
//				Compares  All The Properties
//		3. hashCode() 	Method Code
//				Generates HashCode On All Immutable Properties

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

data class Client3( val name: String, val postalCode: Int ) 

fun playWithClient3() {
	val veeru = Client3("Veeru", 999888 )
	println( "Name: ${veeru.name} ")
	println( "Code: ${veeru.postalCode} ")

	println( veeru ) // println( veeru.toString() )

	val veeruDuplicate = Client3("Veeru", 999888 )
	println("Checking Same To Same Or Not...")
	println( veeru == veeruDuplicate ) // println( veeru.equals( veeruDuplicate ) )

	val reference1 = veeru
	println( veeru == reference1 ) 		// println( veeru.equals( reference1 ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Data Classes
//		Compiler Will Generate Following Functions Code
//		1. equals() 	Method With Code
//				Compares  All The Properties
//		2. hashCode() 	Method Code
//				Generates HashCode On All Immutable Properties

// Will NOT generate toString Method As Programmer Provided Implementation
data class Client4(val name: String, val postalCode: Int) {
	override fun toString() = ">>> Client2(name=$name, postalCode=$postalCode) <<<"
}

fun playWithClient4() {
	val veeru1 = Client4( "Veeru", 111111 )
	println( veeru1 ) // veeru.toString()
	// Client1(name=Veeru, postalCode=111111)

	val veeru2 = Client4( "Veeru", 111111 )
	println( veeru2 ) // veeru.toString()

	val jay = Client4( "Jay", 777777 )
	println( jay ) // jay.toString()

	println( veeru1 == veeru2 ) 
	println( veeru1 == jay )    
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Object Classes
//		Are Signleton Classes In Kotlin
//			and Instance Name Will Be Same As Class Name
object India {
	val name 	= "Bharatvarsh"
	val states  = 32
}

// Kotlin Compiler Will Generate Following Code For The Above Object Class
// class India {
// 		String name = "Bharatvarsha";
//		int states  = 32;
// 		// Make One private static Member Variable To Store Single Instance
//  	public static India INSTANCE = new India() ;
// 		// Make Constructor Private
// 		private India() {} ;
// }

fun playWithIndia() {
	// Accessing India Object Class Instance Using India Only
	println( India.name )
	println( India.states )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Abstract Class
//		We Cann't Create Instances Of Concrete Classes
// class Mammal( val name: String, val birthDate: String ) {

abstract class Mammal( val name: String, val birthDate: String ) {
	abstract fun consumeFood()
}

class Human( name: String, birthDate: String ) : Mammal( name, birthDate ) {
	override fun consumeFood() {
		println("Human Consuming Food...")
	}

	fun createBirthCertificate() = println("Birth Certificate Created For! $name")
}

fun playWithAbstractClasses() {
	// Can't Create Instance/Object Of Abstract Classes
	// val mam = Mammal()
	// println( mam.name )
	val katrina = Human("Katrina Kaif", "16-July-1983")
	katrina.consumeFood()
	katrina.createBirthCertificate()

	println( katrina is Human )
	println( katrina is Mammal )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Following Both Definitions Are Equivalent

//				  Primary Constructor
class PersonAgain1(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

//				    constructor Keyword Is Optional For Primary Constructor
class PersonAgain2 constructor(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

fun playWithPrimaryConstructor() {
	val person1 = PersonAgain1( " Gabbar", "Singh" )
	println( person1.fullName )

	val person2 = PersonAgain2( " Gabbar", "Singh" )
	println( person2.fullName )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

enum class Colour { RED, GREEN, BLUE, WHITE, BLACK }

open class Shape {
	var boundaryColor: Colour
	var fillColor : Colour
	// Secondary Constructors
	//		Convience Constructors i.e. Created For Convenience
	// 		Using Mechanism : Constructor Overloading

	// constructor( ) {
	// 	this.boundaryColor 	= Colour.BLACK
	// 	this.fillColor 		= Colour.WHITE
	// }

	constructor( boundaryColor : Colour ) : this( boundaryColor, Colour.WHITE) {
		// this.boundaryColor 	= boundaryColor
		// this.fillColor 		= Colour.WHITE
	}

	// Following Constructor Makes Constructor Overloading Ambiguous
	//		Because Overloading Works Based On 
	//			Number of Arguments and Type Of Arguments
	// constructor( fillColor : Colour ) {
	// 	this.boundaryColor 	= boundaryColor
	// 	this.fillColor 		= Colour.WHITE
	// }

	constructor( boundaryColor : Colour, fillColor: Colour ) {
		this.boundaryColor 	= boundaryColor
		this.fillColor 		= fillColor
	}

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

// DESIGN PRACTICES
// SECONDARY CONSTRUCTORS DESIGN
// 		1. All Constructors Within Class Should Call Constructor Within
//				Constructor Which Initialises Object Fully
//				i.e. Constructor Which Takes Maximum Number Of Arguments
//				Let's Call It FULL Constructor
//		2.FULL Constructor From Child Class Should Call FULL Constructor From Parent Class
// 

class Circle : Shape {
	var radius : Int 
	// error: explicit 'this' or 'super' call is required. 
	//		There is no constructor in superclass that can be called without arguments
	// constructor( boundaryColor : Colour ) {
	constructor( boundaryColor : Colour ) : this( boundaryColor, Colour.WHITE, 0 ) { //super( boundaryColor ) {
		// this.boundaryColor 	= boundaryColor
		// this.fillColor 		= Colour.WHITE
		// this.radius 		= 0
	}

	constructor( boundaryColor : Colour, fillColor : Colour ) : this( boundaryColor, fillColor, 0 ) {
		// this.boundaryColor 	= boundaryColor
		// this.fillColor 		= fillColor
		// this.radius 		= 0		
	}

	constructor( boundaryColor : Colour, fillColor : Colour, radius : Int ) : super(boundaryColor, fillColor) {
		// this.boundaryColor 	= boundaryColor
		// this.fillColor 		= fillColor
		this.radius 			= radius	
	}

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor, radius=$radius)"	
}


fun playWithShapes() {
	val shape1 = Shape( Colour.RED )
	val shape2 = Shape( Colour.RED, Colour.GREEN )

	println( shape1 )
	println( shape2 )

	val circle1 = Circle( Colour.RED )
	val circle2 = Circle( Colour.RED, Colour.GREEN )
	val circle3 = Circle( Colour.RED, Colour.GREEN, 99 )

	println( circle1 )
	println( circle2 )
	println( circle3 )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// DESIGN PRACTICE
// Constructor Design Choice
//		Always Prefer Primary Constructor with Default Arguments
//			Over Constructor Overloading
//				  Constructor With Default Arguments
class ShapeBetter( val boundaryColor : Colour = Colour.BLACK, val fillColor : Colour = Colour.WHITE ) {
	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

fun playWithShapeBetter() {
	val shape1 = ShapeBetter( Colour.RED )
	val shape2 = ShapeBetter( Colour.RED, Colour.GREEN )

	println( shape1 )
	println( shape2 )

	val shape3 = ShapeBetter( )
	val shape4 = ShapeBetter( boundaryColor = Colour.RED, fillColor = Colour.GREEN )
	val shape5 = ShapeBetter( fillColor = Colour.GREEN, boundaryColor = Colour.RED )
	val shape6 = ShapeBetter( fillColor = Colour.GREEN )
	val shape7 = ShapeBetter( boundaryColor = Colour.RED )
	
	println( shape3 )
	println( shape4 )
	println( shape5 )
	println( shape6 )
	println( shape7 )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithLocalFunctionsAndLocalClasses() { // Enclosing Context A
	var something = 10
	println("Accessing Outside: $something")	
	// Local Function: Function Defined Inside Function
	fun doSomething() { // Enclosed Context B
		println("Local Function doSomething Called!")
		println("1. Accessing Inside: $something")
		something = 111
	}
	println("1. Accessing Outside: $something")

	// Local Class: Class Defined Inside Function
	class Person(val firstName: String, val lastName: String) {  // Enclosing Context C
																 // Enclosed Context w.r.t. A															 
		val somethingAgain = 90
		fun doDance() = println("Dancing With Charm!")  // Enclosed Context w.r.t C
		fun doSomething() { // Enclosed Context w.r.t C
			println("2. Accessing Inside: $something")
			something = somethingAgain
		}
		override fun toString() = "Person(firstName=$firstName, lastName=$lastName)" // Enclosed Context w.r.t. C
	}

	doSomething()
	println("2. Accessing Outside: $something")
	val person = Person( "Gabbar", "Singh" )
	println( person )
	person.doDance()
	person.doSomething()
	println("3. Accessing Outside: $something")
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"
        return "Name : $firstName $lastName, Age: $age"
    }
}

fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


fun main() {
	println("\nFunction : playWithClassesInheritance")
	playWithClassesInheritance()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentAthlete")
	playWithStudentAthlete()

	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithClient2")
	playWithClient2()

	println("\nFunction : playWithClient3")
	playWithClient3()

	println("\nFunction : playWithClient4")
	playWithClient4()

	println("\nFunction : playWithAbstractClasses")
	playWithAbstractClasses()

	println("\nFunction : playWithShapes")
	playWithShapes()

	println("\nFunction : playWithLocalFunctionsAndLocalClasses")
	playWithLocalFunctionsAndLocalClasses()

	println("\nFunction : playWithPrivilegedUser")
	playWithPrivilegedUser()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//__________________________________________________________
/*
https://codebunk.com/b/1061100615545/
https://codebunk.com/b/1061100615545/
https://codebunk.com/b/1061100615545/
*/
//__________________________________________________________

