__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBasicsTutorial.pdf

__________________________________________________________________

DAY 03
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBranchingNotes.pdf

__________________________________________________________________

DAY 04
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A2: Reading and Experimentation Assignment
		Read and Experiment Git Commands For Work Flow

		Reference Notes:
			GitBranchingNotes.pdf
			GitBranchingModelNotes.pdf
			GitFundamentalsNotes.pdf
			GitOnServerNotes.pdf

		Reference Links:
			https://nvie.com/posts/a-successful-git-branching-model/
			https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow

__________________________________________________________________

DAY 05 + SUNDAY
__________________________________________________________________

	// NOTE NOTE: Assignment A1 and Assignment A2 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 02: Types, Operators and Expressions
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A2: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility
			Chapter 3: Managing Dependencies
			Chapter 4: Creating Flexible Interfaces 

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A3: Reading UML Diagrams
		Reference Links:
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://www.lucidchart.com/pages/uml-sequence-diagram
			https://creately.com/guides/sequence-diagram-tutorial/
			https://developer.ibm.com/articles/the-sequence-diagram/

________________________________________________________________________

DAY 06
________________________________________________________________________

	// NOTE NOTE: Assignment A1 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	[ MUST MUST MUST ]
			    ├── KotlinNotes07.Shared.pdf 		[ GOOD TO HAVE ]
			    └── KotlinNotes08-09.Shared.pdf 	[ GOOD TO HAVE ]

________________________________________________________________________

DAY 07
________________________________________________________________________

	Assignment A0: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	[ MUST MUST MUST ]
			    ├── KotlinNotes07.Shared.pdf 		[ GOOD TO HAVE ]

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial07
			    ├── KotlinNotes08-09.Shared.pdf 	[ MUST MUST MUST ]
			 	├── KotlinNotes11.Shared.pdf
			 	└── KotlinNotes13.Shared.pdf

	Assignment A2: Simulate Following Functionality In Java Code
		Write Corresponding Java Code For Following Kotlin Code

			class Person( val name: String, var isMarried: Boolean )

			fun playWithPerson() {
				val gabbar = Person("Gabbar", false)

				println( gabbar.name ) 		// gabbar.getName()
				println( gabbar.isMarried ) // gabbar.getIsMarried()

				// error: val cannot be reassigned
				// gabbar.name = "Gabbar Singh"
				gabbar.isMarried = true 	// gabbar.setIsMarried( true )

				println( gabbar.name ) 		// gabbar.getName()
				println( gabbar.isMarried ) // gabbar.getIsMarried()

				val alice = Person("Alice Carol", true )

				println( alice.name )
				println( alice.isMarried)	
			}

________________________________________________________________________

DAY 08
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial08
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf

		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

	Assignment A3: Write Following Java Code Inside Kotlin File 
		Explore Java Collections CLasses and Interfaes
		Use Folloing Java Collections Classes and APIs Code in Kotlin Code	

		Reference Link
			https://www.digitalocean.com/community/tutorials/collections-in-java-tutorial
		
		Reference Book
			Chapter : java.util Part 1: The Collections Framework 
			Java Complete Reference By Herbert Schildt

		Reference Book:  [ FOR DEEPER UNDERSTANDING ]
			Data Structure Design and Priciples 
				Data Structures and Program Design in C, 2nd Edition
				Data Structures and Program Design in C++ 
						By Robert L Kruse

	Assignment A4: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	

________________________________________________________________________

DAY 09
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial09
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf

		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

	Assignment A3: Write Following Java Code Inside Kotlin File 
		Explore Java Collections CLasses and Interfaes
		Use Folloing Java Collections Classes and APIs Code in Kotlin Code	

		Reference Link
			https://www.digitalocean.com/community/tutorials/collections-in-java-tutorial
		
		Reference Book
			Chapter : java.util Part 1: The Collections Framework 
			Java Complete Reference By Herbert Schildt

		Reference Book:  [ FOR DEEPER UNDERSTANDING ]
			Data Structure Design and Priciples 
				Data Structures and Program Design in C, 2nd Edition
				Data Structures and Program Design in C++ 
						By Robert L Kruse

	Assignment A4: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	


________________________________________________________________________

DAY 10
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial10
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf
				
				├── KotlinNotes15.Shared.pdf
				├── KotlinNotes16.Shared.pdf
				└── KotlinNotes17.Shared.pdf
		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial09
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	
			 	├── KotlinNotes10.Shared.pdf

	Assignment A3: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

________________________________________________________________________

DAY 11
________________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			

		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]

	Assignment A2: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial09
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf
				├── KotlinNotes15.Shared.pdf
				├── KotlinNotes16.Shared.pdf
				└── KotlinNotes17.Shared.pdf
		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A3: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays


________________________________________________________________________

DAY 12
________________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			

		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]
			Chapter 07: Operator Overloading
			
	Assignment A2: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial09
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf
				├── KotlinNotes15.Shared.pdf
				├── KotlinNotes16.Shared.pdf
				└── KotlinNotes17.Shared.pdf
		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A3: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays


________________________________________________________________________

DAY 13
________________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			

		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]
			Chapter 05: Programming With Lambdas
			Chapter 06: Kotlin Types System
			Chapter 07: Operator Overloading
			Chapter 08: Higher Order Functions
			
	Assignment A2: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial09
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf
				├── KotlinNotes15.Shared.pdf
				├── KotlinNotes16.Shared.pdf
				├── KotlinNotes17.Shared.pdf
			    ├── KotlinNotes18.Shared.pdf
			    ├── KotlinNotes20.Shared.pdf
			    └── KotlinNotes22.Shared.pdf

		Practice and Revise Kotlin Code/Ideas In Class 

________________________________________________________________________

DAY 14
________________________________________________________________________

	Assignment A1: Exploration and Thinking Assignment

		Explore and Understand Following Examples

			StudyMaterial14.zip
				AndroidCode00
					TestHelloWorld.zip

				Android.Code01
					ActivitiesJava
					ConfigChangesJava
					ManifestAndResourcesJava
		
				AndroidCode02
					Project.04.01.Layouts

	Assignment A2: Reading and Thinking Android Concepts Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Android Concepts
		
		https://developer.android.com/guide/components/fundamentals
		https://guides.codepath.com/android/Activity-Lifecycle		
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes

	Assignment A3: Android Coding Assignments In Kotlin
		
		Code Following Concepts Examples in Kotlin 

			StudyMaterial14.zip
				AndroidCode00
					TestHelloWorld.zip

				Android.Code01
					ActivitiesJava
					ConfigChangesJava
					ManifestAndResourcesJava
		
				AndroidCode02
					Project.04.01.Layouts

________________________________________________________________________

DAY 15
________________________________________________________________________

	Assignment A1: Reading and Thinking Android Concepts Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Android Concepts

		https://developer.android.com/guide/topics/resources/providing-resources
		https://developer.android.com/guide/topics/resources/runtime-changes
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

	Assignment A2: Android Coding Assignments In Kotlin
		Chapter 01 To Chapter 06
			Read All Chapters
			Code All Examples
			Solve All Challenges At The End Of Chapters

		Reference Book:
			Android Programming Big Nerd Ranch Guide, 4E

________________________________________________________________________

DAY 16
________________________________________________________________________

	Assignment A1: Reading and Thinking Android Concepts Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Android Concepts

		https://guides.codepath.com/android/Using-the-RecyclerView

		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/broadcasts#kotlin

	Assignment A2: Android Coding Assignments In Kotlin
		Chapter 01 To Chapter 10
			Read All Chapters
			Code All Examples
			Solve All Challenges At The End Of Chapters

		Reference Book:
			Android Programming Big Nerd Ranch Guide, 4E


________________________________________________________________________

DAY 17
________________________________________________________________________

	Assignment A1: Android Coding Assignments In Kotlin [ MUST MUST MUST ]
	 	Complete All Chapters
			Read All Chapters
			Code All Examples
			Solve All Challenges At The End Of Chapters

		Reference Book:
			Android Programming Big Nerd Ranch Guide, 4E

	Assignment A2: Reading and Thinking Android Concepts Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Android Concepts

		https://developer.android.com/guide/components/fundamentals
		https://guides.codepath.com/android/Activity-Lifecycle		
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/activities/tasks-and-back-stack

		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

		https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
		https://developer.android.com/guide/fragments#:~:text=A%20Fragment%20represents%20a%20reusable,an%20activity%20or%20another%20fragment.
		https://developer.android.com/guide/fragments/fragmentmanager
		https://developer.android.com/guide/fragments/transactions
		https://developer.android.com/guide/fragments/lifecycle
		https://developer.android.com/guide/fragments/saving-state
		https://developer.android.com/guide/fragments/communicate

		https://developer.android.com/guide/components/broadcasts#kotlin
		https://developer.android.com/guide/components/services

	Assignment A3: Android Sample Applications Coding Assignment

		RecylerView : Code and Experiment Following Example In Kotlin
			https://guides.codepath.com/android/using-the-recyclerview

		Android Developer Fundamentals
			https://developer.android.com/courses/fundamentals-training/toc-v2

		Constraint Layout CodeLab
			https://developer.android.com/codelabs/constraint-layout#0

		Android Basics In Kotlin CodeLab
			https://developer.android.com/courses/android-basics-kotlin/course

	Assignment A4: Create Clear Todo List Application In Swift
			https://apps.apple.com/us/app/clear-todos/id493136154

			Following Best Design Principles
			Loose Coupling and Role and Responsibility Design

	Assignment A5: Additional Study Links

		REFERNCES: ANDROID MODERN ARCHITECHURE
			https://medium.com/ios-os-x-development/ios-architecture-patterns-ecba4c38de52
			https://developer.android.com/courses/android-basics-kotlin/course
			https://developer.android.com/courses/pathways/android-architecture

		REFERENCE APPLICATION: ANDROID APPLICATION MODERN ARCHITECHURE
			Download File: StudyMaterial17.zip And Unzip It!
				StudyMaterial17
					sunflower-main.zip

	Assignment A6: Exploration, Thinking and Understanding Assignment

		Explore and Understand Following Examples
			└── AndroidCode04
			    ├── AndroidFragmentFundamentals
			    ├── AndroidFragmentPizza


________________________________________________________________________

	www.linkedin.com/in/amarjitlife
	amarjitlife@gmail.com
		For Emails Follow Stackoverflow Guidelines
	+91 9980 777 145

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________






