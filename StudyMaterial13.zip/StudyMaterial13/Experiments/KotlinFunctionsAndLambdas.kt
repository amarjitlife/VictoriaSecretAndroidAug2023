// Compiling Kotlin Program
//		kotlinc KotlinFunctionsAndLambdas.kt -include-runtime -d functionsLambdas.jar

// Running Kotlin Code
//		java -jar functionsLambdas.jar


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

enum class Colour {
	RED, GREEN, BLUE, PINK
}

// DESIGN CHOICE
//		Always Prefer All The Exaustive Cases Matching 
//		Rather Than Adding else Branch

fun getStringForColour( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		Colour.BLUE  	-> 		"Blue Colour"
		Colour.PINK     -> 		"Pink Colour"
		// else 		->  	"Unknown Colour"
	}
}


fun getStringForColourAgain( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		// Colour.BLUE  -> 		"Blue Colour"
		// Colour.PINK  -> 		"Pink Colour"
		else 			->  	"Unknown Colour"
	}
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.BLUE ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Function Type Of sum, sub and mul Functions Is
//		(Int, Int) -> Int
fun sum(a: Int, b: Int) : Int { return  a + b }
fun sub(a: Int, b: Int) : Int = a - b
fun mul(a: Int, b: Int) : Int = a * b

fun sum3(a: Int, b: Int, c: Int) : Int { return  a + b + c }

// Higher Order Function
//		Function Which Takes Function/Behaviour As Argument
//				AND/OR
//		Returns Function/Behaviour

fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val xx = 11
	val yy = 22

	var result: Int

	result = calculator( a = xx, b = yy, operation = ::sum )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = ::sub )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = ::mul )
	println("Result : $result ")

	// Lambda Expression : A Code
	//		Generally are small piece of code

	// Following sumLambda and subLambda Expression's Have Type
	//		Function Type (Int, Int ) -> Int
	val sumLambda: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator( a = xx, b = yy, operation = sumLambda )
	println("Result : $result ")

	val subLambda = { x: Int, y: Int -> x - y }
	result = calculator( a = xx, b = yy, operation = subLambda )
	println("Result : $result ")

	val mulLambda = { x: Int, y: Int -> x - y }
	result = calculator( a = xx, b = yy, operation = mulLambda )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = { x: Int, y: Int -> x + y } )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = { x: Int, y: Int -> x - y } )
	println("Result : $result ")

	var something = ::sum // ::sum Will Get Reference Of sum Function
	result = something( 10, 20 )
	println("Result : $result ")	

	something = ::sub
	result = something( 10, 20 )
	println("Result : $result ")	

	something = ::mul
	result = something( 10, 20 )
	println("Result : $result ")	
	
	val somethingAgain: (Int, Int) -> Int = ::sum
	result = somethingAgain( 10, 20 )
	println("Result : $result ")	

	// val somethingMore: (Int, Int) -> Int = ::sum3
	val somethingAgain1: (Int, Int, Int) -> Int = ::sum3
	result = somethingAgain1( 10, 20, 100 )
	println("Result : $result ")	

	// something = ::sum3
	// result = something( 10, 20 )
	// println("Result : $result ")	

	val somethingMore : (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = somethingMore( 111, 222, ::sum )
	println("Result : $result ")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Higher Order Function
//		Function Which Takes Function/Behaviour As Argument
//				AND/OR
//		Returns Function/Behaviour

fun makeIncrementor( amount: Int ) : () -> Int {
    var runningTotal = 0

	fun incrementor() : Int {	
        runningTotal += amount
        return runningTotal
    }
    
    return ::incrementor
}

fun playWithMakeIncrementer() {
	val incrementorByTen: () -> Int = makeIncrementor( amount = 10 )
	println( incrementorByTen() )
	println( incrementorByTen() )
	println( incrementorByTen() )

	val incrementorBySeven: () -> Int = makeIncrementor( amount = 7 )
	println( incrementorBySeven() )
	println( incrementorBySeven() )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

data class Person1( val name: String, val profile: String, val title: String ) 

fun playWithtLambdas() {
	val something: () -> Unit = { println(4000) }
	something()

	val persons = listOf(
		Person1( "Gabbar Singh", "Decoit", "Mr." ), Person1( "Basanti Only", "Heroine", "Mrs." ), 
		Person1( "Veeru", "Hero", "Mr." ), Person1( "Thakur", "Gang Master", "Mr." ), 
		Person1( "Radha", "Heroin", "Mrs." ), Person1( "Mausi",  "Propsective Mother In Law", "Mrs." ), 
		Person1( "Jay", "Hero", "Mr." ),
	)

						// Polymofrphic Function ; By Passing Behvaiour To Behaviour
	val names = persons.joinToString( separator = "  ", 
									  transform = { person: Person1 -> person.name } )	
	println( names )

	val titles = persons.joinToString( separator = " : ", 
									  transform = { person: Person1 -> person.title } )	
	println( titles )

	val profiles = persons.joinToString( separator = " : ", 
									  transform = { person: Person1 -> person.profile } )	
	println( profiles )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithtLambdasAgain() {
	var result : Int
	var multiplyLambda: (Int, Int) -> Int 
	multiplyLambda = { a: Int, b: Int -> a * b }

	result = multiplyLambda( 50, 10 )
	println( result )

	multiplyLambda = { a: Int, b: Int -> Int 
		a * b 
	}
	result = multiplyLambda( 60, 10 )
	println( result )

	multiplyLambda = { a, b -> 
		a * b 
	}
	result = multiplyLambda( 70, 10 )
	println( result )

	var doubleLambda = { a : Int -> 2 * a }
	result = doubleLambda( 11 )
	println( result )

	var doubleLambdaAgain: (Int) -> Int  = { a : Int -> 2 * a }
	result = doubleLambdaAgain( 11 )
	println( result )

	doubleLambda = { a : Int -> 
		2 * a 
	}
	result = doubleLambda( 11 )
	println( result )

	doubleLambda = { 2 * it }
	result = doubleLambda( 11 )
	println( result )

	val square = { number : Int -> number * number }
	result = square( 25 )
	println( result )

	val square1: (Int) -> Int = { number : Int -> number * number }
	result = square1( 25 )
	println( result )	

	val square2: (Int) -> Int = { it * it }
	result = square2( 25 )
	println( result )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithtLambdasOnceAgain() {
	var result: Int

	fun operate( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
		val result1 = operation( a, b )
		return result1
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println( result )

	fun addFunction( a: Int, b: Int ) = a + b 
	result = operate( 40, 20, operation = ::addFunction )
	println( result )

	result = operate( 40, 20, operation = Int::plus )
	println( result )

	result = operate( 40, 20, operation =  { a: Int, b: Int -> a + b } )
	println( result )

	result = operate( 40, 20, 
		operation =  { a: Int, b: Int -> 
			a + b 
		} 
	)
	println( result )

	val magic = ::operate
	result = magic( 100, 200, addLambda )
	println( result )

	result = operate( 40, 20, 
		operation =  { a, b -> 
			a + b 
		} 
	)
	println( result )

	result = operate( 40, 20, operation =  { a, b -> a + b } )
	println( result )

	result = operate( 40, 20, { a, b -> a + b } )
	println( result )

	// Trailing Lambda Syntax
	result = operate( 40, 20 ) { a, b -> a + b } 
	println( result )

	// Trailing Lambda Syntax
	result = operate( 40, 20 ) { 
		a, b -> a + b 
	} 
	println( result )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun chooseSteps( forward: Boolean ) : (Int) -> Int {
	fun moveForward( start: Int ) : Int	  { return start + 1 }
	fun moveBackwards( start : Int ): Int { return start - 1 }
	return if ( forward ) ::moveForward else ::moveBackwards
}

fun playWithChooseStepFunction() {
	// val something: (Boolean) -> Int  = chooseSteps( forward = true )
	// val something: Boolean -> (Int) -> Int  = chooseSteps( forward = true )
	// val something: (Boolean) -> Boolean  = chooseSteps( forward = true )
	// val something: (Boolean) -> (Int)  = chooseSteps( forward = true )
	val something: (Int) -> Int = chooseSteps( forward = true )
	val result = something( 10 )
	println( "Result = $result " )
	// val somethingAgain: (Boolean) -> Int = ::chooseSteps
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	// val magic: Int = somethingAgain( false )
	val magic: (Int) -> Int = somethingAgain( false )
	// val some: (Boolean) -> (Int) -> Int = magic( 90 )
	// val some: (Int) -> Int = magic( 90 )
	// val some: ( Boolean ) -> Int = magic( 90 )
	// val some: (Int) -> (Boolean) -> Int = magic( 90 )
	// val some: (Int) -> Boolean = magic( 90 )
	// val some: ( (Boolean ) -> Int -> Int ) -> (Int) -> Int = magic( 90 )
	val some = magic( 90 )
	println( some )

	val someAgain: Int = magic( 90 )
	println( someAgain )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun printMessageWithPrefix( messages : Collection<String>, prefix: String ) {
	messages.forEach( { println("$prefix $it") } )

	messages.forEach { // Trailing Lambda 
		println("$prefix $it") 
	}
}

fun playWithPrintMessages() {
	val errors = listOf( "404 Not Found", "403 Forbidden", "Bad Code" )
	printMessageWithPrefix( errors, "Error : ")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Polymorphic Function
fun filterStrings( data: String, predicate: (Char) -> Boolean ): String {
	var sb = StringBuilder()

	for( index in 0 until data.length ) {
		val element = data.get( index )
		if ( predicate( element ) ) sb.append( element )
	}

	return sb.toString()
}


fun playWithFilterFunction() {
	val stringData = "ABCDEe19908uBGF777"
	var result: String

	result = filterStrings( data = stringData, predicate = { it in 'a'..'z' } )
	println("Result : $result")

	result = filterStrings( data = stringData, predicate = { it in 'A'..'Z' } )
	println("Result : $result")

	result = filterStrings( data = stringData, predicate = { it in '0'..'9' } )
	println("Result : $result")
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun String.filter( predicate: (Char) -> Boolean ): String {
	var sb = StringBuilder()

	for( index in 0 until this.length ) {
		val element = this.get( index )
		if ( predicate( element ) ) sb.append( element )
	}

	return sb.toString()
}


fun playWithFilterFunctionAgain() {
	val stringData = "ABCDEe19908uBGF777"
	var result: String

	result = stringData.filter( predicate = { it in 'a'..'z' } )
	println("Result : $result")

	result = stringData.filter( predicate = { it in 'A'..'Z' } )
	println("Result : $result")

	result = stringData.filter( predicate = { it in '0'..'9' } )
	println("Result : $result")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

fun main() {	
	println("\nFunction : playWithColour")
	playWithColour()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithMakeIncrementer")
	playWithMakeIncrementer()

	println("\nFunction : playWithtLambdas")
	playWithtLambdas()

	println("\nFunction : playWithtLambdasAgain")
	playWithtLambdasAgain()

	println("\nFunction : playWithtLambdasOnceAgain")
	playWithtLambdasOnceAgain()

	println("\nFunction : playWithPrintMessages")
	playWithPrintMessages()

	println("\nFunction : playWithFilterFunction")
	playWithFilterFunction()

	println("\nFunction : playWithFilterFunctionAgain")
	playWithFilterFunctionAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//__________________________________________________________
// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/
//__________________________________________________________


