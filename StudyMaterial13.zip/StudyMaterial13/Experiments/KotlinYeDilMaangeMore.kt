
/**** Run Following Commands
kotlinc KotlinYeDilMaangeMore.kt -include-runtime -d more.jar
java -jar more.jar
****/

package learnKotlin

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Human {
	// Instance/Object Member Property
	var id : Int = 0
	var name: String = "Unknown"

	// Instance/Object Member Functions
	fun doMagic() {
		println("Doing Magic...")
	}

	fun celebrateOnam() {
		println("Onashamsakal...")		
	}

	// Using companion object
	//		Create Type/Class Members
	//		i.e. Accessed Using Type
	companion object {
		// Creating Type/Class Members
		var haveFunInLife = "Awesome Life!"

		fun doSomething() {
			println("Companion Object doSomething Called...")
		}

		fun doSomethingMore() {
			println("Companion Object doSomethingMore Called...")
		}
	}

	// error: only one companion object is allowed per class
	// companion object {
	// 	fun foo() = println("Foooooo")
	// }
}

fun playWithCompanionObject() {
	// Accessing Class/Type Members Through Class/Type
	Human.doSomething()
	Human.doSomethingMore()
	println( Human.haveFunInLife )

	// Human.doMagic()
	// Human.celebrateOnam()
	// println( "${ Human.id } ${Human.name}" )

	// Accessing Instance/Object Members Through Instance/Object
	val gabbar = Human()
	gabbar.id = 420
	gabbar.name = "Gabbar Singh"

	println( "${ gabbar.id } ${ gabbar.name}" )
	gabbar.doMagic()
	gabbar.celebrateOnam()

	// gabbar.doSomething()
	// gabbar.doSomethingMore()
	// gabbar.haveFunInLife
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// fun equalsResult( first: Int, second: Int ) : Boolean {
// 	return first == second
// }

// fun equalsResult( first: Double, second: Double ) : Boolean {
// 	return first == second
// }

// fun equalsResult( first: String, second: String ) : Boolean {
// 	return first == second
// }

// Generics Code
//		A Tempalte Code To Generate Code

// <T> Type PlaceHolder 
//		Where Type Will Be Get Substituted
//			By Compiler

fun <T> equalsResult( first: T, second: T ) : Boolean {
	return first == second
}

// Compiler Will Generate Following Code Based On Usage: equalsResult( first1, second1 )
//			Infer Types Of Arguments As Int And 
//			Than Substitue T Type Place Holder with Inferred Type Int 
// fun <Int> equalsResult( first: Int, second: Int ) : Boolean {
// 	return first == second
// }

// Compiler Will Generate Following Code Based On Usage: equalsResult( first2, second2 )
//			Infer Types Of Arguments As String And 
//			Than Substitue T Type Place Holder with Inferred Type String
// fun <String> equalsResult( first: String, second: String ) : Boolean {
// 	return first == second
// }

fun playWithEqualResults() {
	val first1 	: Int = 90
	val second1 : Int = 90
	val third1 	: Int = 100

	println( equalsResult( first1, second1 ) )
	println( equalsResult( first1, third1 ) )

	val first2 	: String = "Ding"
	val second2 : String = "Ding"
	val third2 	: String = "Dong"

	println( equalsResult( first2, second2 ) )
	println( equalsResult( first2, third2 ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class MutableStack<E>( vararg items: E ) {              
	private val elements = items.toMutableList()
	fun push(element: E) = elements.add(element)        
	fun peek(): E = elements.last()                     
	fun pop(): E = elements.removeAt(elements.size - 1)
	fun isEmpty() = elements.isEmpty()
	fun size() = elements.size
	override fun toString() = "MutableStack(${elements.joinToString()})"
}

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Generic Extention Property

val <T> List<T>.penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 

fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavorite( cats )
	println( "Favorite Name : ${ favorite.name }" )

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
	for (animal in animals) println( animal.type )
 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain = chooseFavorite( animals )
	// print( favoriteAgain )
}
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class Human( val name: String )
class Owner( name : String ) : Human( name )

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

	val favorite = chooseFavoriteMultiples( cats, owners )
	println( "Favorite Name : ${ favorite.name }" )
}


//_____________________________________________________
//_____________________________________________________

fun main() {
	println("\nFunction : playWithCompanionObject")
	playWithCompanionObject()

	println("\nFunction : playWithEqualResults")
	playWithEqualResults()

	println("\nFunction : playWithJoinToStringFinal")
	playWithJoinToStringFinal()


	println("\nFunction : playWithMutableStack")
	playWithMutableStack()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_____________________________________________________

/*

https://codebunk.com/b/5581100616711/
https://codebunk.com/b/5581100616711/
https://codebunk.com/b/5581100616711/

*/

