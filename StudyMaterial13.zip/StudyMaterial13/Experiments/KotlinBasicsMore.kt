/***
kotlinc KotlinBasicsMore.kt -include-runtime -d basicsMore.jar
java -jar basicsMore.jar 
***/

package learnKotlin

import kotlin.math.*

//_____________________________________________________________________

fun playWithExpressionsVariablesConstants() {
    // COMMENTS
    // This is a comment. It is not executed.

    // This is also a comment.
    // Over multiple lines.

  /* This is also a comment.
     Over many..
     many...
     many lines. */

  /* This is a comment.
      /* 
         And inside it
         is
         another comment.
      */
     Back to the first.
  */

    // PRINT
    println("Hello, Kotlin Apprentice reader!")

    // ARITHMETIC
    println(2 + 6)
    println(10 - 2)
    println(2 * 4)
    println(24 / 3)
    println(2 + 6)
    println(22 / 7)
    println(22.0 / 7.0)
    println(28 % 10)
    println("%.0f".format(28.0 % 10.0))
    println(1.shl(3)) // infix function
    println(32 shr 2)
    println(((8000 / (5 * 10)) - 32) shr (29 % 5))
    println(350 / 5 + 2)
    println(350 / (5 + 2))

    // MATH FUNCTIONS
    println(sin(45 * PI / 180))
    println(cos(135 * PI / 180))
    sqrt(2.0)
    max(5, 10)
    min(-5, -10)
    max(sqrt(2.0), PI / 2)

    // VARIABLES & CONSTANTS
    val number: Int = 10
    // number = 0 /* Val cannot be reassigned */
    val pi: Double = 3.14159 // val pi: Double = 3.14159
    var variableNumber: Int = 42
    variableNumber = 0
    variableNumber = 1_000_000

    // ARITHMETIC WITH VARIABLES
    var counter: Int = 0
    counter += 1
    counter -= 1
    println(counter)

    counter = 10
    counter *= 3
    counter /= 2
    println(counter)
}

//_____________________________________________________________________

fun playWithTypesAndOperations() {
    // CONVERTING TYPES
    var integer: Int = 100
    var decimal: Double = 12.5
    // Error:(34, 15) Kotlin: Type mismatch: inferred type is Double but Int was expected
    // integer = decimal 
    integer = decimal.toInt()

    val hourlyRate: Double = 19.5
    val hoursWorked: Int = 10
    val totalCost: Double = hourlyRate * hoursWorked
    println(totalCost)

    // TYPE INFERENCE
    val typeInferredInt = 42 /* Type = Int */
    val typeInferredDouble = 3.14159 /* Type = Double */

    val wantADouble = 3
    val actuallyDouble = 3.toDouble()
    // val actuallyDouble: Double = 3.0
    // val wantADouble = 3.0

    // CHARACTERS
    val characterA: kotlin.Char = 'a'
    val stringDog = "Dog"

    // STRING CONCATENATION
    var message = "Hello" + " my name is "
    val name = "Joe"
    message += name

    val exclamationMark: Char = '!'
    message += exclamationMark

    // STRING TEMPLATES
    message = "Hello my name is $name!" // "Hello my name is Joe!"

    val oneThird = 1.0 / 3.0
//  val oneThirdLongString = "One third is $oneThird as a decimal."
    val oneThirdLongString = "One third is ${1.0 / 3.0} as a decimal."

    // LONG STRINGS
    val bigString = """
        |You can have a string
        |that contains multiple
        |lines
        |by
        |doing this.
    """.trimMargin()
    println(bigString)

    // TUPLES
    val coordinates: Pair<Int, Int> = Pair(2, 3)
    val coordinatesInferred = Pair(2, 3)
    val coordinatesWithTo = 2 to 3

    val coordinatesDoubles = Pair(2.1, 3.5)
    val coordinatesMixed = Pair(2.1, 3)

    val x1 = coordinates.first
    val y1 = coordinates.second

    val (x, y) = coordinates

    val coordinates3D = Triple(2, 3, 1)
    val (x3, y3, z3) = coordinates3D
    // val x3 = coordinates3D.first
    // val y3 = coordinates3D.second
    // val z3 = coordinates3D.third

    val (x4, y4, _) = coordinates3D
    println(x4)
    println(y4)

    // AS
    val string = "Hello there"
    val charSequence = string as CharSequence

    // NUMBER TYPES
    val a: Short = 12
    val b: Byte = 120
    val c: Int = -100000

    val answer = a + b + c // Answer will be an Int
    println(answer)

    // ANY, UNIT, AND NOTHING TYPES
    val anyNumber: Any = 42
    val anyString: Any = "42"

    fun add() {
        val result = 2 + 2
        println(result)
    }

    fun doNothingForever(): Nothing {
        while (true) {
        }
    }
}

//_____________________________________________________________________

fun playWithControlFlows() {
    // COMPARISON OPERATORS
    // val yes: Bool = true
    // val no: Bool = false
    val yes = true
    val no = false

    val doesOneEqualTwo = (1 == 2)
    val doesOneNotEqualTwo = (1 != 2)
    val alsoTrue = !(1 == 2)
    val isOneGreaterThanTwo = (1 > 2)
    val isOneLessThanTwo = (1 < 2)

    val and = true && true
    val or = true || false

    val andTrue = 1 < 2 && 4 > 3
    val andFalse = 1 < 2 && 3 > 4

    val orTrue = 1 < 2 || 3 > 4
    val orFalse = 1 == 2 || 3 == 4

    val andOr = (1 < 2 && 3 > 4) || 1 < 4

    val guess = "dog"
    val dogEqualsCat = guess == "cat"

    val order = "cat" < "dog"
    println("ORDER = " + order)

    // IF-STATEMENTS
    if (2 > 1) {
        println("Yes, 2 is greater than 1.")
    }

    val animal = "Fox"
    if (animal == "Cat" || animal == "Dog") {
        println("Animal is a house pet.")
    } else {
        println("Animal is not a house pet.")
    }

    // TERNARY OPERATOR
    val a = 5
    val b = 10

  /*
  val min: Int
  if (a < b) {
  min = a
  } else {
  min = b
  }
  */
    val min = if (a < b) a else b

  /*
  val max: Int
  if (a > b) {
  max = a
  } else {
  max = b
  }
  */

    val max = if (a > b) a else b

    val hourOfDay = 12

    val timeOfDay = if (hourOfDay < 6) {
        "Early morning"
    } else if (hourOfDay < 12) {
        "Morning"
    } else if (hourOfDay < 17) {
        "Afternoon"
    } else if (hourOfDay < 20) {
        "Evening"
    } else if (hourOfDay < 24) {
        "Late evening"
    } else {
        "INVALID HOUR!"
    }
    println(timeOfDay)

    val name = "Dicken Lucas"

    if (1 > 2 && name == "Dicken Lucas") {
        // ...
    }

    if (1 < 2 || name == "Dicken Lucas") {
        // ...
    }

    // SCOPE
    var hoursWorked = 45

    var price = 0
    if (hoursWorked > 40) {
        val hoursOver40 = hoursWorked - 40
        price += hoursOver40 * 50
        hoursWorked -= hoursOver40
    }
    price += hoursWorked * 25

    println(price)
    // println(hoursOver40)

    // WHILE LOOPS
    // while true { // Commented out as this will loop forever
    // }

    // Made up sequence (it's powers of 2 minus 1, i.e. 3, 7, 15, 31, 63, etc)
    var sum = 1
    while (sum < 1000) {
        sum = sum + (sum + 1)
    }
    println(sum)

    sum = 1
    do {
        sum = sum + (sum + 1)
    } while (sum < 1000)
    println(sum)

    sum = 1
    while (sum < 1) {
        sum = sum + (sum + 1)
    }
    println(sum)

    sum = 1
    do {
        sum = sum + (sum + 1)
    } while (sum < 1)
    println(sum)

    sum = 1
    while (true) {
        sum = sum + (sum + 1)
        if (sum >= 1000) {
            break
        }
    }
    println(sum)
}

//_____________________________________________________________________

fun playWithControlFlowsAdvanced() {
    // RANGES
    val closedRange = 0..5

    val halfOpenRange = 0 until 5

    val decreasingRange = 5 downTo 0
    for (i in decreasingRange) {
        println(i)
    }

    val count = 10

    // TRIANGLE NUMBERS
    var sum = 0
    for (i in 1..count) {
        sum += i
    }
    println(sum)

    // FIBONACCI
    sum = 1
    var lastSum = 0
    repeat(10) {
        val temp = sum
        sum += lastSum
        lastSum = temp
    }
    println(sum)

    // SUM ODD NUMBERS
    sum = 0
    for (i in 1..count step 2) {
        sum += i
    }
    println(sum)

    // COUNT DOWN
    sum = 0
    for (i in count downTo 1 step 2) {
        sum += i
    }
    println(sum)

    // CHESS BOARD ITERATION
    sum = 0
    for (row in 0 until 8) {
        if (row % 2 == 0) {
            continue
        }

        for (column in 0 until 8) {
            sum += row * column
        }
    }
    println(sum)

    sum = 0
    rowLoop@ for (row in 0 until 8) {
        columnLoop@ for (column in 0 until 8) {
            if (row == column) {
                continue@rowLoop
            }
            sum += row * column
        }
    }
    println(sum)

    // WHEN EXPRESSION
    val number = 10

    when (number) {
        0 -> println("Zero")
        else -> println("Non-zero")
    }

    when (number) {
        10 -> println("It's ten!")
    }

    val string = "Dog"
    when (string) {
        "Cat", "Dog" -> println("Animal is a house pet.")
        else -> println("Animal is not a house pet.")
    }

    val numberName = when (number) {
        2 -> "two"
        4 -> "four"
        6 -> "six"
        8 -> "eight"
        10 -> "ten"
        else -> {
            println("Unknown number")
            "Unknown"
        }
    }

    println(numberName) // > ten

    val hourOfDay = 12
    var timeOfDay: String

    timeOfDay = when (hourOfDay) {
         0, 1, 2, 3, 4, 5 -> "Early morning"
         6, 7, 8, 9, 10, 11 -> "Morning"
         12, 13, 14, 15, 16 -> "Afternoon"
         17, 18, 19 -> "Evening"
         20, 21, 22, 23 -> "Late evening"
         else -> "INVALID HOUR!"
    }

    timeOfDay = when (hourOfDay) {
        in 0..5 -> "Early morning"
        in 6..11 -> "Morning"
        in 12..16 -> "Afternoon"
        in 17..19 -> "Evening"
        in 20..23 -> "Late evening"
        else -> "INVALID HOUR!"
    }
    println(timeOfDay)

    when {
        number % 2 == 0 -> println("Even")
        else -> println("Odd")
    }

    val (x, y, z) = Triple(3, 2, 5)

    when {
        x == 0 && y == 0 && z == 0 -> println("Origin")
        y == 0 && z == 0 -> println("On the x-axis.")
        x == 0 && z == 0 -> println("On the y-axis.")
        x == 0 && y == 0 -> println("On the z-axis.")
        else -> println("Somewhere in space")
    }

    when {
        x == 0 && y == 0 && z == 0 -> println("Origin")
        y == 0 && z == 0 -> println("On the x-axis at x = $x")
        x == 0 && z == 0 -> println("On the y-axis at y = $y")
        x == 0 && y == 0 -> println("On the z-axis at z = $z")
        else -> println("Somewhere in space at x = $x, y = $y, z = $z")
    }

    when {
        x == y -> println("Along the y = x line.")
        y == x * x -> println("Along the y = x^2 line.")
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
   println("\n\nFunction: playWithExpressionsVariablesConstants")
   playWithExpressionsVariablesConstants()

   println("\n\nFunction: playWithTypesAndOperations")
   playWithTypesAndOperations()

   println("\n\nFunction: playWithControlFlows")
   playWithControlFlows()

   println("\n\nFunction: playWithControlFlowsAdvanced")
   playWithControlFlowsAdvanced()

   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
}

