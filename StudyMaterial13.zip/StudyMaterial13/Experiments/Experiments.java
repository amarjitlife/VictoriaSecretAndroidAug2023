// Define The Human
class Human {
	// Member Variables: Instance/Object Member Members
	//		Accessed Using Instance/Object
	//		Though Defined In Class
	int id = 0;
	String name = "Unknown";

	// Member Variable: Class/Type Member Variables
	//		Accessed Using Class/Type Name
	public static String category = "Mammal";

	// Constructor	
	Human(int id, String name) {
		this.id = id;
		this.name = name;
	}

	// Member Function: Instance/Object Member Functions
	//		Accessed Using Instance/Object
	//		Though Defined In Class
	public void dance() { 
		System.out.println( this.name );
		System.out.println("\tDance Buddy Dance!!!");
	}

	int getID() 	 { return this.id; }
	String getName() { return this.name; }

	// Member Function: Class/Type Member Functions
	//		Accessed Using Class/Type Name
	static public String getHumanCulture() {
		return "Human Culture";
	}
}

class Experiments {
	public static void playWithHuman() {
		// Creating Object/Instance of Human Class
		Human gabbar = new Human( 420, "Gabbar Singh" );
		// gabbar is Reference/Pointer To Object Of Human Type
		// Human * gabbar = ( Human * ) malloc( sizeof( Human ) );

		// System.out.println( "\tName: " + gabbar.name );
		// System.out.println( "\tID  : " + gabbar.id );
		System.out.println( "\tName: " + gabbar.getID() );
		System.out.println( "\tID  : " + gabbar.getName() );
		gabbar.dance();

		// String culture = gabbar.getHumanCulture();
		
		// Type Member Function Accessed Using Class/Type i.e. Human Type/Class

		System.out.println("\nAccessing Class/Type Members: Using Class/Type");
		String culture = Human.getHumanCulture();
		System.out.println("\tHuman Culture 	: " + culture );
		System.out.println("\tHuman Category 	: " + Human.category );

	}

	public static void playWithJavaObjects() {
		// Integer something = new Integer(4590);
		// Integer *something = ( Integer * ) malloc( size( Integer ) );
		Integer something = 4590; // new Integer( 4590 );

		System.out.println( something );
		something = null;
		System.out.println( something );
		// something.toString();

		if ( something != null ) something.toString();
		else { System.out.println("Nothiness Found!!!"); }

		// Double somethingAgain = new Double( 90.99 );
		Double somethingAgain = 90.90; // new Double( 90.99 );
		
		System.out.println( somethingAgain );
		somethingAgain = null;
		System.out.println( somethingAgain );

		String greeting = "Good Evening!"; // new String("Good Evening");
		System.out.println( greeting );
		greeting = null;
		System.out.println( greeting );
		// greeting.toString();

		if ( greeting != null ) greeting.toString();
		else { System.out.println("Nothiness Found!!!"); }

	}

	public static void main( String [] args ) {
		System.out.println("\nFunction : playWithHuman");
		playWithHuman();

		System.out.println("\nFunction : playWithJavaObjects");
		playWithJavaObjects();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}


