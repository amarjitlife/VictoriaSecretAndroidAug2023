
// Compiling Kotlin Program
//		kotlinc HelloKotlin.kt -d hello.jar

// RUnning Kotlin Code
//		java -jar hello.jar

fun main() {
	println("Hello To Kotlin World!!!")
}
