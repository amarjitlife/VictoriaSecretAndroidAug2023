// ________________________________________________________
//
// JAVA HELLO WORLD PROGRAM
// ________________________________________________________

// Compling Java Program!
//		javac HelloJava.java -d ClassFiles/

// RUnning Java Program
//		java -cp ClassFiles/ HelloJava 

class HelloJava {
	public static void main( String [] args ) {
		System.out.println("Hello World!!! Testing Java Environment");
	}
}
