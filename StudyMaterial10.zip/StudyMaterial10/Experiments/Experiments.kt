// Compiling Kotlin Program
//		kotlinc Experiments.kt -include-runtime -d experiments.jar

// Running Kotlin Code
//		java -jar experiments.jar

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Function Type Of sum, sub and mul Functions Is
//		(Int, Int) -> Int
fun sum(a: Int, b: Int) : Int { return  a + b }
fun sub(a: Int, b: Int) : Int = a - b
fun mul(a: Int, b: Int) : Int = a * b

fun sum3(a: Int, b: Int, c: Int) : Int { return  a + b + c }

fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val xx = 11
	val yy = 22

	var result: Int

	// val somethingMore: (Int, Int) -> Int = ::sum3
	val somethingMore: (Int, Int, Int) -> Int = ::sum3
	result = somethingMore( 10, 20, 100 )
	println("Result : $result ")	

	result = calculator( a = xx, b = yy, operation = ::sum )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = ::sub )
	println("Result : $result ")

	result = calculator( a = xx, b = yy, operation = ::mul )
	println("Result : $result ")

	var something = ::sum
	result = something( 10, 20 )
	println("Result : $result ")	

	something = ::sub
	something = ::mul
	
	val somethingAgain: (Int, Int) -> Int = ::sum
	result = somethingAgain( 10, 20 )
	println("Result : $result ")	

	// something = ::sum3
	// result = something( 10, 20 )
	// println("Result : $result ")	

	val somethingMore : (Int, Int, (Int, Int) -> ) -> Int= ::calculator
	result = somethingMore()
	println("Result : $result ")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

enum class Colour {
	RED, GREEN, BLUE, PINK
}

// DESIGN CHOICE
//		Always Prefer All The Exaustive Cases Matching 
//		Rather Than Adding else Branch

fun getStringForColour( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		Colour.BLUE  	-> 		"Blue Colour"
		Colour.PINK     -> 		"Pink Colour"
		// else 		->  	"Unknown Colour"
	}
}


fun getStringForColourAgain( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		// Colour.BLUE  -> 		"Blue Colour"
		// Colour.PINK  -> 		"Pink Colour"
		else 			->  	"Unknown Colour"
	}
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.BLUE ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// func makeIncrementor( amount: Int ) -> () -> Int {
fun makeIncrementor( amount: Int ) : () -> Int {
    var runningTotal = 0

    // func incrementor() -> Int {
	fun incrementor() : Int {	
        runningTotal += amount
        return runningTotal
    }
    
    return ::incrementor
}

fun playWithMakeIncrementer() {
	val incrementorByTen: () -> Int = makeIncrementor( amount = 10 )
	println( incrementorByTen() )
	println( incrementorByTen() )
	println( incrementorByTen() )

	val incrementorBySeven: () -> Int = makeIncrementor( amount = 7 )
	println( incrementorBySeven() )
	println( incrementorBySeven() )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________


fun main() {	
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithColour")
	playWithColour()

	println("\nFunction : playWithMakeIncrementer")
	playWithMakeIncrementer()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")

}

