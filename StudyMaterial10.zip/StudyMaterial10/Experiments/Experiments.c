#include <stdio.h>

//______________________________________________

void playWithIfElse() {
	int x = -10;
	int y = 0;

	// CODE 01
	if ( x ) {
		y = 20;
	} else {
		y = 100;
	}

	printf("\n y Value: %d", y );

	// CODE 02
	y = ( x ) ? 20 : 100;
	printf("\n y Value: %d", y );	
}

//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________

int main() {
	printf("\n\nFunction : playWithIfElse");
	playWithIfElse();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

//______________________________________________
