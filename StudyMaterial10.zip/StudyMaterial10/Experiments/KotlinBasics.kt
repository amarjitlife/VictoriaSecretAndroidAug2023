// Compiling Kotlin Program
//		kotlinc KotlinBasics.kt -d basics.jar

// Running Kotlin Code
//		java -jar basics.jar

import java.util.TreeMap


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Function Takes No Arguments 
fun helloWorld() {
	println("Hello To Kotlin World!!!")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Function Takes 
//		Two Arguments Of Int Type
//		Return Value Of Int Type
fun max( a: Int, b: Int ) : Int {
	// In Kotlin Following Syntax Possible
	//		if-else Construct Is An Expression
	//		Expression Is A Statement Having Return Value
	//			It Will Value Of Last Expression Evaluated In A Block
	return if ( a > b ) a else b 

	// return if ( a > b ) {
	// 	a 
	// 	// a + 100
	// } else {
	// 	b
	// 	// b + 10
	// }

	// In C/C++/Java
	//		if-else Construct Is A Statement
	//		i.e. It Doesn't Have Return Value
	// if ( a > b ) {
	// 		return a
	// } else {
	// 		return b		
	// } 
}

fun maximum( a: Int, b: Int ) : Int 	= if ( a > b ) a else b 

fun maximumAgain( a: Int, b: Int ) 		= if ( a > b ) a else b 

fun sum(x : Int, y: Int ) : Int {
	return x + y
}

fun sumAgain(x : Int, y: Int ) = x + y

fun playWithFunctions() {
	var result = max( 100, 200 )
	println( "Result : $result" )

	result = max( 100, -200 )
	println( "Result : $result" )

	result = maximum( 100, -200 )
	println( "Result : $result" )

	result = maximumAgain( 100, -200 )
	println( "Result : $result" )

	result = sum(111, 222)
	println( "Result : $result" )

	result = sumAgain(111, 222)
	println( "Result : $result" )	
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// class Person(
// 		val name: String, 
// 		var isMarried: Boolean
// )

// val Is Immutable Property
// var Is Mutable Property

// Int Kotlin 
// Kotlin Compiler Will Generate Following Things
// For The Person Class
//		1. Two Member Variable Correspoding To Each Member Property
//				i.e. name And isMarried Properties
//		2. For Immutable Property Getter Will Be Generated
//				i.e. val Property -> name Property 
//		3. For Mutable Property Getter and Setter Will Be Generated
//				i.e. var Property 
//		4. Will Generated Memberwise Initiliser
//				i.e. Constructor To Initialise All The Member Properties

class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	val gabbar = Person("Gabbar", false)

	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	//error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh"
	gabbar.isMarried = true 	// gabbar.setIsMarried( true )

	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	val alice = Person("Alice Carol", true )

	println( alice.name )
	println( alice.isMarried)	
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Creating Rectanle Class Three Immutable Properties
//		viz. width, height and isSquare
//		heigh And width Are Called Stored Properties
//		isSquare Is Computed Property

class Rectangle( val height: Int, val width: Int ) {
	val isSquare: Boolean
		// Defining Custom Getter For isSquare Property
		// Hence Compiler Will Not Generate Getter	
		// get() {
		// 	return isSquare// height == width
		// }
		get() {
			println("isSquare Property Getter Called...")
			return height == width
		}
}

fun playWithRetangle() {
	val rectangle1 = Rectangle(200, 400)
	println( rectangle1.width )   // rectangle1.getWidth()
	println( rectangle1.height )  // rectangle1.getHeight()
	println( rectangle1.isSquare ) // rectangle1.getIsSquare()

	val rectangle2 = Rectangle(400, 400)
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare)
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithTypeInferrencingAndTypeBinding() {
	// 1. Type Inferrencing Will Happen From RHS Value
	// 2. Type Binding (Inferred Type From RHS) Will Be Binded With LHS 

	// 1. Type Inferred From RHS Value Is Int
	// 2. Int Inferred Type Binded With LHS
	//		Hence something Will Have Int Type	
	val something = 10
	println( something )

	// Annotating Type Explicitly
	val somethingAgain: Int = 10
	println( somethingAgain )

	val someValue = 90.90
	println( someValue )

	val someValueAgain: Double = 90.90
	println( someValueAgain )

	val someValue1 = 90.90F
	println( someValue1 )

	val someValueAgain1: Float = 90.90F
	println( someValueAgain1 )

	val greeting = "Good Evening!"
	val greetingAgain: String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Colour Is An Enum Colour Type
//		Having Set Of Three Values: { RED, GREEN, BLUE }

enum class Colour {
	RED, GREEN, BLUE, PINK
}

// DESIGN CHOICE
//		Always Prefer All The Exaustive Cases Matching 
//		Rather Than Adding else Branch

fun getStringForColour( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		Colour.BLUE  	-> 		"Blue Colour"
		Colour.PINK     -> 		"Pink Colour"
		// else 		->  	"Unknown Colour"
	}
}

fun getStringForColourAgain( colour: Colour ) : String {
	// when Is An Expression	
	// error: 'when' expression must be exhaustive, 
	// 		add necessary 'BLUE' branch or 'else' branch instead
	return when( colour ) {
		// Matching Options Possible
		Colour.RED  	-> 		"Red Colour"
		Colour.GREEN  	-> 		"Green Colour"
		Colour.BLUE  	-> 		"Blue Colour"
		Colour.PINK     -> 		"Pink Colour"
		// else 		->  	"Unknown Colour"
	}
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.BLUE ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

interface Expr
//			class Num Implements Interace Expr
class Num( val value: Int ) : Expr 
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e : Expr ) : Int {
	// e Is Type Of Expr
	// If e is Num  Is True 
	//		Type Cast e To Num Type
	if ( e is Num ) { // Smart TYpe Casting
		// e Is Type Of Num
		return e.value
	}
	// e Is Type Of Expr
	// If e is Sum Tyue Is True 
	//		Type Cast e To Sum Type
	if ( e is Sum ) {
		// e Is Type Of Sum
		return eval( e.left ) + eval( e.right )
	}
	throw IllegalArgumentException("Unkown Expression!!!")
}

fun playWithEval() {
	var result : Int
	result = eval( Sum( Num(100), Num(200) ) )
	println("Result : $result")
	result = eval( Sum( Sum( Num(100), Num(200) ) , Num(1000) ) )
	println("Result : $result")
}

//__________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr 
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalIf( e : Expr ) : Int  {
	return if ( e is Num ) { 
		e.value
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unkown Expression!!!")
	}
}

fun playWithEvalIf() {
	var result : Int
	result = evalIf( Sum( Num(100), Num(200) ) )
	println("Result : $result")
	result = evalIf( Sum( Sum( Num(100), Num(200) ) , Num(1000) ) )
	println("Result : $result")
}

//__________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr 
// class Sum( val left: Expr, val right: Expr ) : Expr

// error: type checking has run into a recursive problem. 
// Easiest workaround: specify types of your declarations explicitly
// fun evalIfAgain( e : Expr )  = if ( e is Num ) { 
fun evalIfAgain( e : Expr ) :Int  = if ( e is Num ) { 
		e.value
	} else if ( e is Sum ) {
		evalIfAgain( e.left ) + evalIfAgain( e.right )
	} else {
		throw IllegalArgumentException("Unkown Expression!!!")
}

fun playWithEvalIfAgain() {
	var result : Int
	result = evalIfAgain( Sum( Num(100), Num(200) ) )
	println("Result : $result")
	result = evalIfAgain( Sum( Sum( Num(100), Num(200) ) , Num(1000) ) )
	println("Result : $result")
}

//__________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr 
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evaluate( expression : Expr ) : Int  = when ( expression ) {
	is Num 	-> 	expression.value
	is Sum  -> 	evaluate( expression.left ) + evaluate( expression.right )
	else 	-> throw IllegalArgumentException("Unkown Expression!!!")
}

fun playWithEvaluate() {
	var result : Int
	result = evaluate( Sum( Num(100), Num(200) ) )
	println("Result : $result")
	result = evaluate( Sum( Sum( Num(100), Num(200) ) , Num(1000) ) )
	println("Result : $result")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// when Expression Used For Pattern Matching
fun fizzBuzz( number : Int ) = when {
	number % 15 == 0 -> "FizzBuzz "
	number %  5 == 0 -> "FIzz "
	number %  3 == 0 -> "Buzz "
	else 			 -> " $number "
}

fun playWithFizzBuzz() {
	for ( number in 1..50) { // Closed Interval [1, 50]
		print( fizzBuzz( number ) )
	}

	for ( number in 50 downTo 1 step 2 ) {
		print( fizzBuzz( number ) )
	}
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// import java.util.TreeMap

fun playWithJavaTreeMap() {
	val binaryRepresentation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary 
	}

	for ( ( letter, binary ) in binaryRepresentation ) {
		println("\t $letter = $binary ")
	}
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun isLetter( character : Char )   	= character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character : Char )	= character !in '0'..'9'

fun recogrnise( character : Char ) = when( character ) {
	in '0'..'9' 				-> "It's A Digit!"
	in 'a'..'z', in 'A'..'Z'    -> "It's A Letter"
	else  						-> "Unknown Letter"
}

fun playWithFunctionsWithIn() {
	println( isLetter( 'Q') )
	println( isLetter( 'A') )

	println( isNotDigit( 'Q') )
	println( isNotDigit( '0') )

	println( recogrnise( 'Q') )
	println( recogrnise( '0') )
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : playWithFunctions")
	playWithFunctions()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithRetangle")
	playWithRetangle()

	println("\nFunction : vplayWithTypeInferrencingAndTypeBinding")
	playWithTypeInferrencingAndTypeBinding()

	println("\nFunction : playWithColour")
	playWithColour()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvalIfAgain")
	playWithEvalIfAgain()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithFizzBuzz")
	playWithFizzBuzz()

	println("\nFunction : playWithJavaTreeMap")
	playWithJavaTreeMap()

	println("\nFunction : playWithFunctionsWithIn")
	playWithFunctionsWithIn()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//___________________________________________________
//___________________________________________________

// https://codebunk.com/b/6641100615408/
// https://codebunk.com/b/6641100615408/
// https://codebunk.com/b/6641100615408/

// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/

//___________________________________________________
//___________________________________________________

