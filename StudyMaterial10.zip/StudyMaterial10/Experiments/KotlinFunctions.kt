// Compiling Kotlin Program
//		kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

// Running Kotlin Code
//		java -jar functions.jar

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithKotlinCollections() {
	val set 	= hashSetOf(1, 7, 53) 
	val list 	= arrayListOf(1, 7, 53) 
	val map 	= hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println( set.javaClass )
    println( list.javaClass )
    println( map.javaClass )

    val strings = listOf("first", "second", "fourteenth")
    println( strings.javaClass )
    println( strings.last() )
    
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)
    //println(numbers.max())
    println(numbers.maxOrNull())
}

// Function : playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// fourteenth
// class java.util.LinkedHashSet
// 14

// Jvaa Collections Tutorial
// https://www.digitalocean.com/community/tutorials/collections-in-java-tutorial

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithKotlinCollectionsIteration() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )

	for ( name in names ) {
		println( name )
	}

	for ( item in names.withIndex() ) {
		println( item )
	}

	for( ( index, name ) in names.withIndex() ) {
		println( "At Index : $index Name: $name" )
	}
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun getLastCharacter( string: String ) : Char = string.get( string.length - 1 )

// Extension Function
//		lastCharacter Is An Extention Function On Class String
//			Using Extentions You Can Added Functionlaity
//				To Existing Classes
//			Where You Will String In Code, Addded Funcality Will Be Available
fun String.lastCharacter() : Char = this.get( this.length - 1 )

fun String.doMagic() = println("Doing Magic with String Class Extension Functions...")

fun playWithLastCharacter() {
	println( getLastCharacter("Kotlin!") )
	println( getLastCharacter("Life is Awesome$$$#") )

	println( "Kotlin!".lastCharacter() )
	println( "Life is Awesome$$$#".lastCharacter() )

	"".doMagic()
	"Gabbar Sinhg".doMagic()

	val basanti = "Basanti"
	basanti.doMagic()
}

// Function : playWithLastCharacter
// !
// #
// !
// #

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun joinToString(
	collection: ArrayList<String>,
	seperator : String,
	prefix : String,
	postfix : String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )

	println( joinToString( names, " : ", " ( ", " ) " ) )
	println( joinToString( names, " #### ", " [ ", " ] " ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun joinToStringWithDefault(
	collection: ArrayList<String>,
	seperator : String = " ", // Initialing Argument With Default Value
	prefix : String = "",     // Initialing Argument With Default Value
	postfix : String = ""     // Initialing Argument With Default Value
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringWithDefaults() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )

	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " : " ) )
	println( joinToStringWithDefault( names, " : ", " ( " ) )
	println( joinToStringWithDefault( names, " : ", " ( ", " ) "  ) )
	println( joinToStringWithDefault( names,  prefix = " ( ", postfix = " ) "  ) )

	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " #### " ) )
	println( joinToStringWithDefault( names, " #### ", " [ " ) )
	println( joinToStringWithDefault( names, " #### ", " [ ", " ] " ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun ArrayList<String>.joinToStringExtension(
	// collection: ArrayList<String>,
	seperator : String = " ", // Initialing Argument With Default Value
	prefix : String = "",     // Initialing Argument With Default Value
	postfix : String = ""     // Initialing Argument With Default Value
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )

	println( names.joinToStringExtension() )
	println( names.joinToStringExtension( " : " ) )
	println( names.joinToStringExtension( " : ", " ( " ) )
	println( names.joinToStringExtension( " : ", " ( ", " ) "  ) )
	println( names.joinToStringExtension( prefix = " ( ", postfix = " ) "  ) )

	println( names.joinToStringExtension() )
	println( names.joinToStringExtension( " #### " ) )
	println( names.joinToStringExtension( " #### ", " [ " ) )
	println( names.joinToStringExtension( " #### ", " [ ", " ] " ) )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Extension Properties

// lastChar Is Immutable Extension Property To String Class
val String.lastChar : Char
	get() = get( length - 1 )

// lastChar Is Mutable Extension Property To StringBuilder Class
var StringBuilder.lastChar : Char 
	get() = get( length - 1 )
	set( value : Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithExtentionProperties() {
	println( "Kotlin!".lastChar )
	println( "Life Is Awesome$$$#".lastChar )

	var keseHo = StringBuilder( "How are you?" )
	
	println( keseHo.toString() )
	println( keseHo.lastChar )

	keseHo.lastChar = '$'
	println( keseHo.toString() )
	println( keseHo.lastChar )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class User( val id : Int, val name: String, val address: String )

fun saveUser( user: User ) {
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User: ${user.id} NAME EMPTY")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User: ${user.id} ADDRESS EMPTY")
	}

	// Logic For Saving User Data In Database...
	saveUserInDatabase( user )
}

fun saveUserInDatabase( user: User ) {
	println("Saving User ${user.id} In Database!")
}

fun playWithSaveUser() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	saveUser( gabbar )
	saveUser( basanti )
	saveUser( samba )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// class User( val id : Int, val name: String, val address: String )

fun saveUserAgain( user: User ) {
	// Local Function
	//		Function Defined Inside Function
	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: ${user.id} $fieldName EMPTY")
		}
	}
	validate( user, user.name, "NAME" )
	validate( user, user.address, "ADDRESS" )

	// Logic For Saving User Data In Database...
	saveUserInDatabase( user )
}

fun playWithSaveUserAgain() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	saveUserAgain( gabbar )
	saveUserAgain( samba )
	saveUserAgain( basanti )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun User.save( ) {
	// Local Function
	//		Function Defined Inside Function
	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: ${user.id} $fieldName EMPTY")
		}
	}
	validate( this, this.name, "NAME" )
	validate( this, this.address, "ADDRESS" )

	// Logic For Saving User Data In Database...
	saveUserInDatabase( this )
}

fun playWithSaveExtension() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	gabbar.save()
	samba.save()
	basanti.save()
}

//__________________________________________________________

fun sum(a: Int, b: Int) : Int { return  a + b }
fun sub(a: Int, b: Int) : Int = a - b

fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

fun playWithCalculator() {
	val aa = 11
	val bb = 22

	var result: Int

	result = calculator( x = aa, y = bb, operation = ::sum )
	println("Result : $result ")

	result = calculator( x = aa, y = bb, operation = ::sub )
	println("Result : $result ")

}



//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

fun main() {
	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithKotlinCollectionsIteration")
	playWithKotlinCollectionsIteration()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithJoinToStringWithDefaults")
	playWithJoinToStringWithDefaults()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithExtentionProperties")
	playWithExtentionProperties()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUserAgain")
	playWithSaveUserAgain()

	println("\nFunction : playWithSaveExtension")
	playWithSaveExtension()
	
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/
// https://codebunk.com/b/1061100615545/

