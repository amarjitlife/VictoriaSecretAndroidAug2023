__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBasicsTutorial.pdf

__________________________________________________________________

DAY 03
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBranchingNotes.pdf

__________________________________________________________________

DAY 04
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A2: Reading and Experimentation Assignment
		Read and Experiment Git Commands For Work Flow

		Reference Notes:
			GitBranchingNotes.pdf
			GitBranchingModelNotes.pdf
			GitFundamentalsNotes.pdf
			GitOnServerNotes.pdf

		Reference Links:
			https://nvie.com/posts/a-successful-git-branching-model/
			https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow

__________________________________________________________________

DAY 05 + SUNDAY
__________________________________________________________________

	// NOTE NOTE: Assignment A1 and Assignment A2 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 02: Types, Operators and Expressions
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A2: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility
			Chapter 3: Managing Dependencies
			Chapter 4: Creating Flexible Interfaces 

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A3: Reading UML Diagrams
		Reference Links:
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://www.lucidchart.com/pages/uml-sequence-diagram
			https://creately.com/guides/sequence-diagram-tutorial/
			https://developer.ibm.com/articles/the-sequence-diagram/

________________________________________________________________________

DAY 06
________________________________________________________________________

	// NOTE NOTE: Assignment A1 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	[ MUST MUST MUST ]
			    ├── KotlinNotes07.Shared.pdf 		[ GOOD TO HAVE ]
			    └── KotlinNotes08-09.Shared.pdf 	[ GOOD TO HAVE ]

________________________________________________________________________

DAY 07
________________________________________________________________________

	Assignment A0: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	[ MUST MUST MUST ]
			    ├── KotlinNotes07.Shared.pdf 		[ GOOD TO HAVE ]

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial07
			    ├── KotlinNotes08-09.Shared.pdf 	[ MUST MUST MUST ]
			 	├── KotlinNotes11.Shared.pdf
			 	└── KotlinNotes13.Shared.pdf

	Assignment A2: Simulate Following Functionality In Java Code
		Write Corresponding Java Code For Following Kotlin Code

			class Person( val name: String, var isMarried: Boolean )

			fun playWithPerson() {
				val gabbar = Person("Gabbar", false)

				println( gabbar.name ) 		// gabbar.getName()
				println( gabbar.isMarried ) // gabbar.getIsMarried()

				// error: val cannot be reassigned
				// gabbar.name = "Gabbar Singh"
				gabbar.isMarried = true 	// gabbar.setIsMarried( true )

				println( gabbar.name ) 		// gabbar.getName()
				println( gabbar.isMarried ) // gabbar.getIsMarried()

				val alice = Person("Alice Carol", true )

				println( alice.name )
				println( alice.isMarried)	
			}

________________________________________________________________________

DAY 08
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial08
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf

		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

	Assignment A3: Write Following Java Code Inside Kotlin File 
		Explore Java Collections CLasses and Interfaes
		Use Folloing Java Collections Classes and APIs Code in Kotlin Code	

		Reference Link
			https://www.digitalocean.com/community/tutorials/collections-in-java-tutorial
		
		Reference Book
			Chapter : java.util Part 1: The Collections Framework 
			Java Complete Reference By Herbert Schildt

		Reference Book:  [ FOR DEEPER UNDERSTANDING ]
			Data Structure Design and Priciples 
				Data Structures and Program Design in C, 2nd Edition
				Data Structures and Program Design in C++ 
						By Robert L Kruse

	Assignment A4: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	

________________________________________________________________________

DAY 09
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial09
			 	├── KotlinNotes10.Shared.pdf
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf

		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

	Assignment A3: Write Following Java Code Inside Kotlin File 
		Explore Java Collections CLasses and Interfaes
		Use Folloing Java Collections Classes and APIs Code in Kotlin Code	

		Reference Link
			https://www.digitalocean.com/community/tutorials/collections-in-java-tutorial
		
		Reference Book
			Chapter : java.util Part 1: The Collections Framework 
			Java Complete Reference By Herbert Schildt

		Reference Book:  [ FOR DEEPER UNDERSTANDING ]
			Data Structure Design and Priciples 
				Data Structures and Program Design in C, 2nd Edition
				Data Structures and Program Design in C++ 
						By Robert L Kruse

	Assignment A4: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial06
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	


________________________________________________________________________

DAY 10
________________________________________________________________________


	Assignment A1: Reading, Thinking and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In Kotlin			
			├── StudyMaterial10
			 	├── KotlinNotes11.Shared.pdf
			 	├── KotlinNotes12.Shared.pdf
			 	├── KotlinNotes13.Shared.pdf
			 	├── KotlinNotes14.Shared.pdf
				
				├── KotlinNotes15.Shared.pdf
				├── KotlinNotes16.Shared.pdf
				└── KotlinNotes17.Shared.pdf
		Practice and Revise Kotlin Code/Ideas In Class 

	Assignment A2: REVISION Assignment Kotlin Notes
		Read, Think and Experiment Code In Kotlin
			└── StudyMaterial09
			    ├── KotlinNotes02-06.Shared.pdf 	
			    ├── KotlinNotes07.Shared.pdf 		
			    ├── KotlinNotes08-09.Shared.pdf 	
			 	├── KotlinNotes10.Shared.pdf

	Assignment A3: REVISION, Think and Experimentation Assignment [ MUST MUST MUST ]
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays


________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________


