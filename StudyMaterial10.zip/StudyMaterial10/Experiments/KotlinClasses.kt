/***
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
***/

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// In Java
//		Clasess Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Clasess Are Final By Default
//			Can't Be Inherited From
//		Member Functions Are Also Final By Default
//			Can't Be Overridden
//		override Keyword Required To Override Parent Class Function

// error: this type is final, so it cannot be inherited from
// class View {

open class View {
	// error: 'click' in 'View' is final and cannot be overridden
	// fun click() = println("View Clicked!")
	open fun click() = println("View Clicked!")
}

// Inheritance Of View Class TO Button Class

// error: this type has a constructor, and thus must be initialized here
// class Button : View {
class Button : View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier
	// fun click() = println("Button Clicked!")

	override fun click() = println("Button Clicked!")
	fun magic() = println("Button Magic...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	val viewAgain: View = View()
	viewAgain.click()
	// viewAgain.magic()

	// Reference Of Parent Type Can STore objecct Store Object of Child Class
	val viewOnceAgain: View = Button()
	viewOnceAgain.click()
	// viewOnceAgain.magic()

	val letBringBackKiddu = viewOnceAgain as Button
	letBringBackKiddu.click()
	letBringBackKiddu.magic()
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

open class View1 {
	open fun click() = println("View Clicked!")
}

// Inheritance Of View Class TO Button Class

class Button1 : View1() {
	override fun click() = println("Button Clicked!")
	fun magic() = println("Button Magic...")
}

// Extension Function
fun View1.showOff() 	= println("View1 showOff Called...")
fun Button1.showOff() 	= println("Button1 showOff Called...")

fun playWithInheritanceAgain() {
	val view = View1()
	view.click()
	view.showOff()

	val button = Button1()
	button.click()
	button.magic()
	button.showOff()

	val viewAgain: View1 = View1()
	viewAgain.click()
	viewAgain.showOff()
	// viewAgain.magic()

	// Reference Of Parent Type Can STore objecct Store Object of Child Class
	val viewOnceAgain: View1 = Button1()
	viewOnceAgain.click()
	// viewOnceAgain.magic()
	viewOnceAgain.showOff()
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithInheritanceAgain")
	playWithInheritanceAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
